from .imgproc import Image, Font, convert, generate, crop, default
from .telegraph import upload, download

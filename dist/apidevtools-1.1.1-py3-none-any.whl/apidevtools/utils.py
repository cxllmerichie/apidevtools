inf: int = 2147483647
